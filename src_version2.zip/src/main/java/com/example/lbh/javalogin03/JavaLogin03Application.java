package com.example.lbh.javalogin03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaLogin03Application {
    public static void main(String[] args) {
        SpringApplication.run(JavaLogin03Application.class, args);
    }

}
