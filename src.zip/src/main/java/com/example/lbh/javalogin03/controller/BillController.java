package com.example.lbh.javalogin03.controller;


import com.baidu.aip.face.AipFace;
import com.example.lbh.javalogin03.domain.Bill;
import com.example.lbh.javalogin03.domain.User;
import com.example.lbh.javalogin03.repository.BillDao;
import com.example.lbh.javalogin03.repository.UserDao;
import com.example.lbh.javalogin03.service.BillService;
import com.example.lbh.javalogin03.utils.Result;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;

@RestController
@RequestMapping("/bill")
public class BillController {
    @Resource
    private BillService billService;

    @Resource
    private BillDao billDao;

    @Autowired
    private AipFace aipFace;

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public Result<Bill> insertController(@RequestBody Bill bill){
        Bill newBill = billService.insertService(bill);
        return Result.success(newBill,"insert success！");
    }

    @RequestMapping(value = "/searchPast", method = RequestMethod.GET)
    public Result<ArrayList<Bill>> searchPastController(@RequestParam Long uid){
        //get uname by uid
        String uname = billService.getUnameByUid(uid);
        int days = 7;
        String[] pastDays = generatePastDays(days);
        ArrayList<Bill> output= new ArrayList<Bill>();
        for (int i = 0; i < days; i++) {
            Bill newBill = billService.findRecordService(uname,pastDays[i]);
            if(newBill != null){
                output.add(newBill);
            }
        }
        for (int i = 0; i < output.size(); i++) {
            System.out.println(output.get(i).toString());
        }
        return Result.success(output,"enjoy the data");
    }

    @RequestMapping(value = "/searchTenantAllBill", method = RequestMethod.GET)
    public Result<ArrayList<Bill>> searchTenantAllBillController(@RequestParam Long uid){
        //get uname by uid
        String uname = billService.getUnameByUid(uid);
        //get all bill by uname
        ArrayList<Bill> output = billService.findAllRecordService(uname);
        for (int i = 0; i < output.size(); i++) {
            System.out.println(output.get(i).toString());
        }
        return Result.success(output,"enjoy the data");
    }

    @RequestMapping(value = "/searchLandlordAllBill", method = RequestMethod.GET)
    public Result<ArrayList<Bill>> searchAllBillController(@RequestParam Long uid){
        //get uname by uid
        String uname = billService.getUnameByUid(uid);
        //get all bill by uname
        ArrayList<Bill> output = billService.findAllRecordService(uname);
        for (int i = 0; i < output.size(); i++) {
            System.out.println(output.get(i).toString());
        }
        return Result.success(output,"enjoy the data");
    }





    public String[] generatePastDays(int numberOfDays) {
        String[] output = new String[numberOfDays];
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        for (int i = 0; i < numberOfDays; i++) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -i);
            output[i] = formatter.format(cal.getTime());
        }
        return output;
    }

}